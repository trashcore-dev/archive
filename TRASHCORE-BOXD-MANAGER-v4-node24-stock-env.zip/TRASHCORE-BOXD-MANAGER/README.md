# TRASHCORE BOXD MANAGER

CommonJS Telegram bot for Boxd VPS provisioning.

Requires Node.js 22 or newer. The SQLite dependency is pinned to a release with bundled Linux binaries for supported architectures.

## Features
- Boxd API key verification and AES-256-GCM encrypted storage
- Ubuntu 24.04 VPS creation with confirmation
- Each new non-admin user starts with 10 credits
- VPS creation costs 100 credits for non-admins
- Admin IDs in `ADMIN_IDS` create VPSs for free
- Daily reward: 10 credits, once per East Africa calendar day
- Menu stats: registered users, active VPSs, credits, Boxd machine quota, date/time/year, owner
- Uses the default machine domain reported by Boxd; no custom domain prompt
- Per-user VPS ownership checks

## Boxd machine availability
Set the optional `BOXD_API_KEY` in `.env` to show the Boxd organization's available machine quota in the `/start` and `/help` stats. The bot calls the read-only `boxd.orgs.getMachineLimit()` SDK method and displays `maxVms - vmCount` as the remaining slots, alongside the used/limit figures. The API key must be issued for the organization; Boxd documents `vmCount` as the Frankfurt machine count. See Boxd's [TypeScript SDK reference](https://docs.boxd.sh/reference/typescript-sdk) under “Machine limit”. This is a quota-derived count, not physical datacenter inventory.

The environment key is only used for that read-only quota lookup. Each user still connects their own Boxd key with `/connect` for creating and managing their machines.

## Install
```bash
npm install
cp .env.example .env
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```
Set `BOT_TOKEN`, `MASTER_KEY`, and `ADMIN_IDS` in `.env`. Optionally set `BOXD_API_KEY` to enable the Boxd quota display, then:
```bash
npm start
```

There is no baked-in administrator account: `ADMIN_IDS` must contain your own Telegram numeric user ID or IDs. The displayed owner handle is `@trashcoredev2`.

## Commands
- `/start`
- `/connect`
- `/create`
- `/myvps`
- `/status [machine-id]`
- `/claim`
- `/balance`
- `/adminstats`

## Domain and installation scope
The v4 `/install` command provisions Panel + Wings + Nightshift on a fresh Ubuntu 24.04 Boxd machine, using the machine's default Boxd domain. Boxd HTTPS proxy routing, WebSocket behavior, Wings API reachability, and raw port forwarding still need to be tested before calling a deployment production-ready.

The bot does not create or reveal a root password. Use Boxd's documented SSH access flow and the keys configured in the Boxd account.

## Security
Keep `.env`, `MASTER_KEY`, and `database.sqlite` private. Back up the master key securely. Never post Boxd API keys in group chats. VPS creation can incur charges in the Boxd account, so the bot asks for confirmation. The real `.env` file is ignored by Git and is not included in the project ZIP; only `.env.example` is included.


## v4 automatic Panel + Wings installer

- `/install` installs on the latest VPS owned by the user.
- `/install MACHINE_ID` selects an owned VPS.
- `/installstatus` reports the current phase and recent installer log.

The installer targets a fresh Ubuntu 24.04 guest. It installs Docker and the Panel dependencies, pins the Boxd default HTTPS hostname to local Nginx:80, creates the `wings` HTTPS proxy to local Wings:8080, exposes TCP guest SFTP port 2022 and configures Wings to bind internally to 2022 while the Panel advertises the Boxd public forwarded port, installs Pterodactyl 1.15.2, builds and applies Nightshift from the pinned commit `ecf1f9b5ee52bad7a0339d025c4e994a8f41f836`, installs Wings, creates a Panel location and node, configures Behind Proxy, and checks local services.

It refuses to overwrite an existing Panel. It requires root execution or non-interactive sudo inside the Boxd machine.

The installer fetches the pinned Nightshift commit and builds its release archive on the guest. It stops if the fetched source does not report Panel version 1.15.2.

This installer cannot honestly guarantee zero errors on every Boxd image or repository revision. It verifies local services but public Boxd proxy WebSocket compatibility must be tested in the browser. Boxd allows at most three raw TCP/UDP forwards per machine; the installer uses one for SFTP and does not fabricate a large game-port allocation range. The Panel admin email is a login identifier, not a mailbox; configure SMTP separately for email delivery.
