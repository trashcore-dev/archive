const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');
const config = require('./config');
const db = require('./lib/db');
const { encrypt, decrypt } = require('./lib/crypto');
const { getBoxd, normaliseMachine } = require('./lib/boxd');
const { getAvailableMachineStock } = require('./lib/boxd-stock');
const { prepareAndStart, readStatus } = require('./lib/installer');

const bot = new TelegramBot(config.botToken, { polling: true });
const sessions = new Map();
const pendingCreates = new Map();
const installMonitors = new Set();

const isAdmin = id => config.adminIds.includes(String(id));
const todayEAT = () => new Intl.DateTimeFormat('en-CA', {
  timeZone: 'Africa/Nairobi', year: 'numeric', month: '2-digit', day: '2-digit'
}).format(new Date());

function dateTimeEAT() {
  return new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Africa/Nairobi',
    weekday: 'short', day: '2-digit', month: 'short',
    year: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit',
    hour12: false
  }).format(new Date());
}

function privateOnly(msg) {
  return msg.chat && msg.chat.type === 'private';
}
function userKey(userId) {
  const row = db.getKey(userId);
  if (!row) return null;
  return decrypt({ cipher: row.key_cipher, iv: row.key_iv, tag: row.key_tag });
}
function memoryLabel(bytes) {
  return bytes ? `${(bytes / (1024 ** 3)).toFixed(1)} GiB` : 'Not reported';
}
// Legacy Markdown helpers (still used by the plain /status command reply).
function md(value) {
  return String(value ?? '').replace(/([_*`[])/g, '\\$1');
}
function code(value) {
  return String(value ?? '').replace(/`/g, "'");
}
// HTML escape for the styled menu screens.
const esc = value => String(value ?? '').replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));

function safeError(err) {
  return String(err && err.message || 'Unknown error')
    .replace(/bxd_[A-Za-z0-9_-]+/g, '[redacted]').slice(0, 240);
}

// ─────────────── Style (same look as the Velvora menu) ───────────────
const TITLE = '┏❐  ⌜ 𝐓𝐑𝐀𝐒𝐇𝐂𝐎𝐑𝐄 ⌟ ❐';
const DIV   = '──────────────';
const FOOT  = '© <b>TRASHCORE BOT</b>';

const head    = sub => `${TITLE}\n┃⭔ <b>${sub}</b>`;
const item    = text => `┃⭔ ${text}`;
const line    = (label, value) => `┃⭔ <b>${label}:</b> ${value}`;
const section = (title, lines) => [`❐ <b>${title}</b>`, ...lines].join('\n');
// frame('TITLE', [section, section], '<i>optional tagline</i>')
const frame = (sub, sections, tagline) =>
  `${head(sub)}${tagline ? `\n┃⭔ ${tagline}` : ''}\n<blockquote>${sections.join(`\n${DIV}\n`)}</blockquote>\n${FOOT}`;
// one-section status screen from plain strings (escaped here)
const note = (sub, ...lines) => frame(sub, [section('STATUS', lines.map(l => item(esc(l))))]);

// /start screen: just a welcome and one button
function startText() {
  return frame('BOXD MANAGER', [
    section('WELCOME', [
      item('Create and manage Boxd VPS machines.'),
      item('Install Pterodactyl Panel + Wings in one tap.')
    ])
  ], '<i>Fast, simple, secure.</i>');
}

// shown after "Open Menu": the buttons are the menu, the caption lists the commands
function menuText() {
  return frame('MENU', [
    section('COMMANDS', [
      item('/start — welcome screen'),
      item('/connect — connect Boxd key'),
      item('/create — create a VPS'),
      item('/myvps — list your VPSs'),
      item('/install — Panel + Wings'),
      item('/installstatus — progress'),
      item('/claim — daily 10 credits'),
      item('/balance — your credits')
    ])
  ], '<i>Pick an option below.</i>');
}

let stockCache = { at: 0, text: '' };

async function stockLine() {
  if (!config.boxdApiKey) return 'Not configured; add BOXD_API_KEY to .env';
  if (stockCache.text && Date.now() - stockCache.at < 60000) return stockCache.text;
  let text;
  try {
    const boxd = await getBoxd(config.boxdApiKey);
    const { available, used, limit } = await getAvailableMachineStock(boxd);
    text = `${available} available (${used}/${limit} used)`;
  } catch {
    text = 'Unavailable; check BOXD_API_KEY permissions';
  }
  stockCache = { at: Date.now(), text };
  return text;
}

async function statsText(userId) {
  const stats = db.stats();
  const user = db.getUser(userId);
  const credits = isAdmin(userId) ? 'Unlimited (Admin)' : (user ? user.credits : config.initialCredits);
  const stock = await stockLine();
  return frame('STATS', [
    section('OVERVIEW', [
      line('Boxd slots (Frankfurt quota)', esc(stock)),
      line('Users', stats.users),
      line('Active VPS', stats.activeVps),
      line('Your credits', esc(credits))
    ]),
    section('TIME', [
      line('Date / Time', `${esc(dateTimeEAT())} EAT`),
      line('Owner', esc(config.owner))
    ])
  ]);
}

// ─────────────── Menu / screens ───────────────
// The menu is ONE photo message. Every button edits its caption (and keyboard)
// instead of sending new messages.
const BACK_ROW = [{ text: 'Back to menu', callback_data: 'menu_home' }];
const cbOk = (prefix, id) => `${prefix}:${id}`.length <= 64;

const startKeyboard = [[{ text: 'Open Menu', callback_data: 'menu_home' }]];

function mainKeyboard(userId) {
  const rows = [
    [{ text: 'Create VPS', callback_data: 'menu_create' }, { text: 'My VPS', callback_data: 'menu_vps' }],
    [{ text: 'Install Panel', callback_data: 'menu_install' }, { text: 'Install Status', callback_data: 'menu_installstatus' }],
    [{ text: 'Connect API', callback_data: 'menu_connect' }, { text: 'Claim Daily 10', callback_data: 'menu_claim' }],
    [{ text: 'Balance', callback_data: 'menu_balance' }, { text: 'Stats', callback_data: 'menu_stats' }],
    [{ text: 'Help', callback_data: 'menu_help' },
     { text: 'Owner', url: `https://t.me/${config.owner.replace(/^@/, '')}` }]
  ];
  if (isAdmin(userId)) rows.push([{ text: 'Admin Stats', callback_data: 'menu_admin' }]);
  return rows;
}

let menuPhotoId = null; // cache Telegram's file_id so the 1.7 MB image is uploaded only once

async function sendMenu(chatId, userId) {
  const opts = {
    caption: startText(), parse_mode: 'HTML',
    reply_markup: { inline_keyboard: startKeyboard }
  };
  if (fs.existsSync(config.menuImage)) {
    for (const source of [menuPhotoId, config.menuImage]) {
      if (!source) continue;
      try {
        const sent = await bot.sendPhoto(chatId, source, opts);
        const id = sent && sent.photo && sent.photo.length && sent.photo[sent.photo.length - 1].file_id;
        if (id) menuPhotoId = id;
        return sent;
      } catch (err) {
        if (source === menuPhotoId) menuPhotoId = null; // stale id, retry with the file
        console.error('[menu photo failed]', safeError(err));
      }
    }
  }
  return bot.sendMessage(chatId, opts.caption, { parse_mode: 'HTML', reply_markup: opts.reply_markup });
}

// Edits the screen the person tapped on: caption if it is the photo menu, text otherwise.
// If editing is impossible, falls back to a new message so a result is never lost.
async function showScreen(message, text, rows = []) {
  const edit = parseMode => {
    const opts = {
      chat_id: message.chat.id, message_id: message.message_id,
      reply_markup: { inline_keyboard: rows },
      ...(parseMode ? { parse_mode: parseMode } : {})
    };
    return message.photo ? bot.editMessageCaption(text, opts) : bot.editMessageText(text, opts);
  };
  try {
    return await edit('HTML');
  } catch (err) {
    if (/message is not modified/i.test(String(err && err.message))) return;
    console.error('[screen edit failed]', safeError(err));
    try {
      return await bot.sendMessage(message.chat.id, text, { parse_mode: 'HTML', reply_markup: { inline_keyboard: rows } });
    } catch {
      return bot.sendMessage(message.chat.id, text.replace(/<[^>]+>/g, ''), { reply_markup: { inline_keyboard: rows } });
    }
  }
}

function noVpsScreen(message) {
  return showScreen(message, note('MY VPS', 'You have no VPS yet.', 'Create one first.'),
    [[{ text: 'Create VPS', callback_data: 'menu_create' }], BACK_ROW]);
}

function createPrompt(userId) {
  if (!db.getKey(userId)) {
    return { text: note('CREATE VPS', 'Connect your Boxd API key first.'),
      rows: [[{ text: 'Connect API', callback_data: 'menu_connect' }], BACK_ROW] };
  }
  const user = db.getUser(userId);
  if (!isAdmin(userId) && user.credits < config.vpsCost) {
    return {
      text: frame('CREATE VPS', [section('CREDITS', [
        line('VPS cost', `${config.vpsCost} credits`),
        line('Your balance', user.credits),
        item('Claim your daily 10 credits to top up.')
      ])]),
      rows: [[{ text: 'Claim Daily 10', callback_data: 'menu_claim' }], BACK_ROW]
    };
  }
  pendingCreates.set(String(userId), true);
  return {
    text: frame('CREATE VPS', [
      section('CONFIRM', [
        line('Image', 'Ubuntu 24.04'),
        line('CPU', `${config.defaultVcpu} vCPU`),
        line('Memory', esc(config.defaultMemory)),
        line('SSH', 'enabled'),
        line('Cost', isAdmin(userId) ? 'FREE (Admin)' : `${config.vpsCost} credits`)
      ]),
      section('NOTE', [item('This creates a potentially billable machine in your Boxd account.')])
    ]),
    rows: [[{ text: 'Confirm creation', callback_data: 'create_confirm' },
            { text: 'Cancel', callback_data: 'create_cancel' }], BACK_ROW]
  };
}

function installPrompt(userId, row) {
  pendingCreates.set(`install:${userId}`, row.id);
  return {
    text: frame('INSTALL PANEL', [
      section('TARGET', [line('VPS', esc(row.name))]),
      section('SETUP', [
        line('Panel', 'Pterodactyl 1.15.2'),
        line('Theme', 'Nightshift'),
        line('Wings', 'wings subdomain'),
        line('OS', 'Ubuntu 24.04'),
        line('Timezone', 'Africa/Nairobi')
      ]),
      section('NOTE', [
        item('Use only on a fresh machine.'),
        item('Existing Panel data will not be overwritten.')
      ])
    ]),
    rows: [[{ text: 'Start installation', callback_data: 'install_confirm' },
             { text: 'Cancel', callback_data: 'install_cancel' }], BACK_ROW]
  };
}

// m: { name, id, status, vcpu, memoryBytes, domain, url, sshPort }
function machineSections(m, extra = []) {
  return [
    section('MACHINE', [
      line('Name', `<code>${esc(m.name)}</code>`),
      line('ID', `<code>${esc(m.id)}</code>`),
      line('Status', esc(m.status || 'unknown'))
    ]),
    section('RESOURCES', [
      line('CPU', `${m.vcpu || config.defaultVcpu} vCPU`),
      line('Memory', memoryLabel(m.memoryBytes)),
      ...extra
    ]),
    section('ACCESS', [
      line('Domain', m.domain ? esc(m.domain) : 'Not reported'),
      line('URL', m.url ? esc(m.url) : 'Not reported'),
      line('SSH port', m.sshPort || 'See Boxd dashboard')
    ])
  ];
}

function machineText(row) {
  return frame('VPS DETAILS', machineSections({
    name: row.name, id: row.id, status: row.status, vcpu: row.vcpu,
    memoryBytes: row.memory_bytes, domain: row.domain, url: row.url, sshPort: row.ssh_port
  }));
}

function machineRows(id) {
  return [
    [{ text: 'Refresh status', callback_data: `vps_refresh:${id}` }],
    [{ text: 'Install Panel', callback_data: `vps_install:${id}` },
     { text: 'Install Status', callback_data: `vps_istatus:${id}` }],
    [{ text: 'My VPS', callback_data: 'menu_vps' }, { text: 'Menu', callback_data: 'menu_home' }]
  ];
}

async function screenMachine(message, userId, id) {
  const row = db.getMachine(id, userId);
  if (!row) return showScreen(message, note('VPS DETAILS', 'Machine not found.'), [[{ text: 'My VPS', callback_data: 'menu_vps' }], BACK_ROW]);
  return showScreen(message, machineText(row), machineRows(row.id));
}

async function screenVpsList(message, userId) {
  const rows = db.listMachines(userId);
  if (!rows.length) return noVpsScreen(message);
  const shown = rows.slice(0, 8);
  const text = frame('MY VPS', [
    section(`YOUR VPS (${rows.length})`, shown.map((m, i) => item(`${i + 1}. ${esc(m.name)} — ${esc(m.status || 'unknown')}`))),
    section('TIP', [item('Tap a VPS below to manage it.')])
  ]);
  const buttons = shown.filter(m => cbOk('vps_view', m.id))
    .map((m, i) => [{ text: `${i + 1}. ${m.name}`.slice(0, 40), callback_data: `vps_view:${m.id}` }]);
  return showScreen(message, text, [...buttons, BACK_ROW]);
}

// Runs `action` straight away when the user has one VPS, otherwise asks which one.
async function machinePicker(message, userId, action, title) {
  const rows = db.listMachines(userId);
  if (!rows.length) return noVpsScreen(message);
  if (rows.length === 1) return runMachineAction(message, userId, action, rows[0].id);
  const buttons = rows.slice(0, 8).filter(m => cbOk(action, m.id))
    .map((m, i) => [{ text: `${i + 1}. ${m.name}`.slice(0, 40), callback_data: `${action}:${m.id}` }]);
  return showScreen(message, note('SELECT VPS', title), [...buttons, BACK_ROW]);
}

function installationProgress(machineName, output) {
  const raw = String(output || '').replace(/```/g, '').trim();
  const [statusBlock = '', logBlock = ''] = raw.split(/--- LOG TAIL ---/);
  const statusLine = statusBlock.split(/\r?\n/).map(line => line.trim()).filter(Boolean).at(-1) || '';
  const match = statusLine.match(/^\d{4}-\d{2}-\d{2}T\S+\s+\|\s*(.+)$/);
  const stage = match ? match[1] : /status not available/i.test(statusLine)
    ? 'Waiting for the installer process to initialize…'
    : statusLine || 'Waiting for the installer to report its first step…';
  const failed = /^FAILED\b/i.test(stage);
  const complete = /^COMPLETE:/i.test(stage);
  const title = complete ? 'INSTALLATION COMPLETE' : failed ? 'INSTALLATION FAILED' : 'INSTALLATION IN PROGRESS';
  const recent = logBlock.split(/\r?\n/).map(line => line.trim()).filter(Boolean)
    .filter(line => !/^No installer log yet\.?$/i.test(line)).slice(-3);
  const sections = [
    section('VPS', [line('Name', `<code>${esc(machineName)}</code>`)]),
    section('CURRENT STEP', [item(esc(stage))])
  ];
  if (recent.length) sections.push(section('RECENT OUTPUT', recent.map(line => item(`<code>${esc(line.slice(0, 140))}</code>`))));
  return { text: frame(title, sections), terminal: failed || complete };
}

async function monitorInstallation(chatId, userId, machineId, machineName) {
  const monitorId = `${chatId}:${machineId}`;
  if (installMonitors.has(monitorId)) return;
  installMonitors.add(monitorId);
  const keyboard = [[{ text: 'Refresh progress', callback_data: `vps_istatus:${machineId}` }]];
  let progressMessage;
  let lastText = '';
  const editProgress = text => bot.editMessageText(text, {
    chat_id: chatId, message_id: progressMessage.message_id,
    parse_mode: 'HTML', reply_markup: { inline_keyboard: keyboard }
  });
  try {
    const initial = installationProgress(machineName, 'Installer status not available yet.');
    progressMessage = await bot.sendMessage(chatId, initial.text, {
      parse_mode: 'HTML', reply_markup: { inline_keyboard: keyboard }
    });
    lastText = initial.text;
    // Keep the user updated for up to one hour; manual Install Status remains available after that.
    let monitoring = true;
    for (let attempt = 0; attempt < 180; attempt++) {
      await new Promise(resolve => setTimeout(resolve, 20000));
      const key = userKey(userId);
      if (!key) {
        const paused = frame('INSTALLATION IN PROGRESS', [
          section('VPS', [line('Name', `<code>${esc(machineName)}</code>`)]),
          section('STATUS', [item('Automatic updates paused because the Boxd API key is unavailable. Use Refresh progress to check manually.')])
        ]);
        if (paused !== lastText) await editProgress(paused);
        monitoring = false;
        break;
      }
      let output;
      try {
        output = await readStatus(key, machineId);
      } catch (err) {
        const retrying = frame('INSTALLATION IN PROGRESS', [
          section('VPS', [line('Name', `<code>${esc(machineName)}</code>`)]),
          section('STATUS', [item(`Could not refresh progress just now; retrying automatically. ${esc(safeError(err))}`)])
        ]);
        if (retrying !== lastText) {
          await editProgress(retrying);
          lastText = retrying;
        }
        continue;
      }
      const progress = installationProgress(machineName, output);
      if (progress.text !== lastText) {
        await editProgress(progress.text);
        lastText = progress.text;
      }
      if (progress.terminal) {
        monitoring = false;
        break;
      }
    }
    if (monitoring) {
      const paused = frame('INSTALLATION STATUS', [
        section('VPS', [line('Name', `<code>${esc(machineName)}</code>`)]),
        section('STATUS', [item('Automatic updates paused after one hour. Installation may still be running; use Refresh progress or /installstatus to check it.')])
      ]);
      if (paused !== lastText) await editProgress(paused);
    }
  } catch (err) {
    if (progressMessage) {
      const text = frame('INSTALL PROGRESS', [section('UPDATE', [
        item('Automatic progress updates stopped.'),
        item(`Use Refresh progress to check again. ${esc(safeError(err))}`)
      ])]);
      try { await editProgress(text); } catch {}
    }
    console.error('[install progress monitor failed]', safeError(err));
  } finally {
    installMonitors.delete(monitorId);
  }
}

async function screenInstallStatus(message, userId, id) {
  const row = db.getMachine(id, userId);
  if (!row) return showScreen(message, note('INSTALL STATUS', 'Machine not found.'), [BACK_ROW]);
  const rows = [[{ text: 'Refresh', callback_data: `vps_istatus:${row.id}` },
                 { text: 'VPS details', callback_data: `vps_view:${row.id}` }], BACK_ROW];
  const key = userKey(userId);
  if (!key) return showScreen(message, note('INSTALL STATUS', 'Connect your Boxd API key first.'),
    [[{ text: 'Connect API', callback_data: 'menu_connect' }], BACK_ROW]);
  try {
    const output = String(await readStatus(key, row.id)).replace(/```/g, '').trim();
    // captions hold 1024 chars, so only the most recent lines are shown
    const lines = output.split('\n').map(l => l.trim()).filter(Boolean).slice(-9).map(l => l.slice(0, 70));
    return showScreen(message, frame('INSTALL STATUS', [
      section('VPS', [line('Name', esc(row.name))]),
      section('PROGRESS', (lines.length ? lines : ['No output yet.']).map(l => item(esc(l))))
    ]), rows);
  } catch (err) {
    return showScreen(message, note('INSTALL STATUS', 'Could not read installer status.', safeError(err)), rows);
  }
}

async function runMachineAction(message, userId, action, id) {
  if (action === 'vps_install') {
    const row = db.getMachine(id, userId);
    if (!row) return showScreen(message, note('INSTALL PANEL', 'Machine not found.'), [BACK_ROW]);
    const p = installPrompt(userId, row);
    return showScreen(message, p.text, p.rows);
  }
  if (action === 'vps_istatus') return screenInstallStatus(message, userId, id);
  if (action === 'vps_view') return screenMachine(message, userId, id);
}

const HELP_TEXT = frame('HELP', [
  section('MENU', [item('Use the buttons, or these commands:')]),
  section('COMMANDS', [
    item('/start — open the menu'),
    item('/connect — connect Boxd API key'),
    item('/create — create a VPS'),
    item('/myvps — list your VPSs'),
    item('/status — refresh a VPS status'),
    item('/install — Panel + Wings + Nightshift'),
    item('/installstatus — installer progress'),
    item('/claim — claim daily 10 credits'),
    item('/balance — check your credits')
  ])
]);

function register(msg) {
  db.registerUser(msg.from.id, msg.from.username || null);
}

bot.onText(/^\/start(?:@\w+)?$/, async msg => {
  if (!privateOnly(msg)) return bot.sendMessage(msg.chat.id, 'Please open a private chat with me.');
  register(msg);
  await sendMenu(msg.chat.id, msg.from.id);
});
bot.onText(/^\/help(?:@\w+)?$/, async msg => {
  if (!privateOnly(msg)) return;
  register(msg);
  await sendMenu(msg.chat.id, msg.from.id);
});
bot.onText(/^\/connect(?:@\w+)?$/, async msg => {
  if (!privateOnly(msg)) return bot.sendMessage(msg.chat.id, 'Use /connect in a private chat.');
  register(msg);
  sessions.set(String(msg.from.id), { action: 'boxd_key' });
  await bot.sendMessage(msg.chat.id, 'Send your Boxd API key here in this private chat. It is encrypted before storage. Never send it in a group.');
});

bot.on('message', async msg => {
  if (!privateOnly(msg) || !msg.text || msg.text.startsWith('/')) return;
  const session = sessions.get(String(msg.from.id));
  if (!session || session.action !== 'boxd_key') return;
  sessions.delete(String(msg.from.id));
  const key = msg.text.trim();
  try { await bot.deleteMessage(msg.chat.id, msg.message_id); } catch {}
  // when /connect was started from the menu, the result goes into the menu caption
  const reply = (text, rows) => session.menu
    ? showScreen(session.menu, note('CONNECT API', ...text), rows)
    : bot.sendMessage(msg.chat.id, text.join('\n'));
  if (key.length < 12 || key.length > 512) {
    return reply(['That key does not look valid.', 'Try Connect API again.'],
      [[{ text: 'Connect API', callback_data: 'menu_connect' }], BACK_ROW]);
  }
  try {
    const boxd = await getBoxd(key);
    await boxd.machines.list();
    const encrypted = encrypt(key);
    db.saveKey({
      telegram_id: String(msg.from.id),
      key_cipher: encrypted.cipher, key_iv: encrypted.iv,
      key_tag: encrypted.tag, created_at: new Date().toISOString()
    });
    await reply(['Boxd API key verified and saved securely.'],
      [[{ text: 'Create VPS', callback_data: 'menu_create' }], BACK_ROW]);
  } catch (err) {
    await reply(['Could not verify that Boxd key.', safeError(err)],
      [[{ text: 'Connect API', callback_data: 'menu_connect' }], BACK_ROW]);
  }
});

bot.onText(/^\/claim(?:@\w+)?$/, async msg => {
  if (!privateOnly(msg)) return;
  register(msg);
  const result = db.claimDaily(msg.from.id, todayEAT());
  if (result.ok) {
    return bot.sendMessage(msg.chat.id, `Daily reward claimed: +10 credits.\nYour balance: ${result.credits} credits.`);
  }
  return bot.sendMessage(msg.chat.id, `You have already claimed today's reward.\nYour balance: ${result.credits} credits.`);
});
bot.onText(/^\/balance(?:@\w+)?$/, async msg => {
  if (!privateOnly(msg)) return;
  register(msg);
  const user = db.getUser(msg.from.id);
  await bot.sendMessage(msg.chat.id, isAdmin(msg.from.id)
    ? 'Admin account: VPS creation is free.'
    : `Your balance: ${user.credits} credits.\nVPS creation cost: ${config.vpsCost} credits.\nDaily reward: ${config.dailyReward} credits.`);
});

bot.onText(/^\/create(?:@\w+)?$/, async msg => {
  if (!privateOnly(msg)) return bot.sendMessage(msg.chat.id, 'VPS creation is only available in a private chat.');
  register(msg);
  const p = createPrompt(msg.from.id);
  await bot.sendMessage(msg.chat.id, p.text, { parse_mode: 'HTML', reply_markup: { inline_keyboard: p.rows } });
});

bot.on('callback_query', async query => {
  const userId = String(query.from.id);
  const message = query.message;
  let answered = false;
  const answer = async text => {
    if (answered) return;
    answered = true;
    try { await bot.answerCallbackQuery(query.id, text ? { text } : {}); } catch {}
  };
  if (!message || !message.chat || message.chat.type !== 'private') {
    return answer('Use the bot in a private chat.');
  }
  db.registerUser(query.from.id, query.from.username || null);
  const data = String(query.data || '');
  const arg = data.includes(':') ? data.slice(data.indexOf(':') + 1) : '';

  try {
    // ── main menu + simple screens ──
    if (data === 'menu_home') {
      await answer();
      sessions.delete(userId);
      return showScreen(message, menuText(), mainKeyboard(userId));
    }
    if (data === 'menu_stats') {
      await answer();
      return showScreen(message, await statsText(userId), [[{ text: 'Refresh', callback_data: 'menu_stats' }], BACK_ROW]);
    }
    if (data === 'menu_create') {
      await answer();
      const p = createPrompt(userId);
      return showScreen(message, p.text, p.rows);
    }
    if (data === 'create_cancel') {
      pendingCreates.delete(userId);
      await answer('Cancelled.');
      return showScreen(message, note('CREATE VPS', 'VPS creation cancelled.'), [BACK_ROW]);
    }
    if (data === 'menu_claim') {
      await answer();
      const result = db.claimDaily(userId, todayEAT());
      return showScreen(message, frame('DAILY REWARD', [section(result.ok ? 'CLAIMED' : 'ALREADY CLAIMED', [
        item(result.ok ? `+${config.dailyReward} credits added.` : "You already claimed today's reward."),
        line('Balance', `${result.credits} credits`)
      ])]), [[{ text: 'Balance', callback_data: 'menu_balance' }], BACK_ROW]);
    }
    if (data === 'menu_balance') {
      await answer();
      const u = db.getUser(userId);
      return showScreen(message, frame('BALANCE', [section('CREDITS', isAdmin(userId)
        ? [item('Admin account: VPS creation is free.')]
        : [
          line('Balance', `${u ? u.credits : config.initialCredits} credits`),
          line('VPS cost', `${config.vpsCost} credits`),
          line('Daily reward', `${config.dailyReward} credits`)
        ])]),
        [[{ text: 'Claim Daily 10', callback_data: 'menu_claim' }], BACK_ROW]);
    }
    if (data === 'menu_help') {
      await answer();
      return showScreen(message, HELP_TEXT, [BACK_ROW]);
    }
    if (data === 'menu_admin') {
      if (!isAdmin(userId)) return answer('Admins only.');
      await answer();
      const st = db.stats();
      return showScreen(message, frame('ADMIN STATS', [section('OVERVIEW', [
        line('Users', st.users),
        line('Active VPS', st.activeVps),
        line('Total VPS records', st.totalVps),
        line('Owner', esc(config.owner))
      ])]), [[{ text: 'Refresh', callback_data: 'menu_admin' }], BACK_ROW]);
    }
    if (data === 'menu_connect') {
      await answer();
      sessions.set(userId, { action: 'boxd_key', menu: message });
      return showScreen(message, frame('CONNECT API', [section('STEPS', [
        item('Send your Boxd API key as a message in this chat.'),
        item('It is deleted right away and stored encrypted.'),
        item('Never send it in a group.')
      ])]), [[{ text: 'Cancel', callback_data: 'menu_home' }]]);
    }

    // ── VPS screens ──
    if (data === 'menu_vps') { await answer(); return screenVpsList(message, userId); }
    if (data === 'menu_install') { await answer(); return machinePicker(message, userId, 'vps_install', 'Choose the VPS to install the Panel on:'); }
    if (data === 'menu_installstatus') { await answer(); return machinePicker(message, userId, 'vps_istatus', 'Choose the VPS to check:'); }
    if (data.startsWith('vps_view:') || data.startsWith('vps_install:') || data.startsWith('vps_istatus:')) {
      await answer();
      return runMachineAction(message, userId, data.slice(0, data.indexOf(':')), arg);
    }
    if (data.startsWith('vps_refresh:')) {
      const row = db.getMachine(arg, userId);
      if (!row) { await answer('Machine not found.'); return; }
      const key = userKey(userId);
      if (!key) { await answer('Connect your Boxd API key first.'); return; }
      await answer('Refreshing…');
      try {
        const boxd = await getBoxd(key);
        const m = normaliseMachine(await boxd.machines.get(row.id));
        db.updateMachine(m.status, m.domain, m.url, m.sshPort, m.vcpu, m.memoryBytes, row.id, userId);
      } catch (err) {
        return showScreen(message, note('VPS DETAILS', 'Could not refresh machine status.', safeError(err)),
          [[{ text: 'VPS details', callback_data: `vps_view:${row.id}` }], BACK_ROW]);
      }
      return screenMachine(message, userId, row.id);
    }

    // ── install flow ──
    if (data === 'install_cancel') {
      pendingCreates.delete(`install:${userId}`);
      await answer('Cancelled.');
      return showScreen(message, note('INSTALL PANEL', 'Panel + Wings installation cancelled.'), [BACK_ROW]);
    }
    if (data === 'install_confirm') {
      const machineId = pendingCreates.get(`install:${userId}`);
      pendingCreates.delete(`install:${userId}`);
      if (!machineId || !db.getMachine(machineId, userId)) {
        await answer('Request expired.');
        return showScreen(message, note('INSTALL PANEL', 'Installation request expired.', 'Start it again from the menu.'), [BACK_ROW]);
      }
      await answer('Starting installer…');
      await showScreen(message, note('INSTALL PANEL', 'Preparing Boxd proxies and starting the installer…'), []);
      try {
        const key = userKey(userId);
        if (!key) throw new Error('Connect your Boxd API key first.');
        const row = db.getMachine(machineId, userId);
        const details = await prepareAndStart(key, { id: row.id, name: row.name });
        // credentials stay in their own message so they survive menu navigation
        await bot.sendMessage(message.chat.id, frame('INSTALLER STARTED', [
          section('PANEL', [
            line('Panel URL', esc(`https://${details.panelDomain}`)),
            line('Wings URL', esc(`https://${details.wingsDomain}:443`)),
            line('SFTP public port', esc(details.sftpPublicPort))
          ]),
          section('ADMIN LOGIN', [
            line('Email', `<code>${esc(details.adminEmail)}</code>`),
            line('Username', `<code>${esc(details.adminUsername)}</code>`),
            line('Password', `<code>${esc(details.adminPassword)}</code>`)
          ]),
          section('NOTES', [
            item('Keep these credentials private.'),
            item('The Panel is available when installation finishes.'),
            item('Boxd allows max three raw TCP/UDP forwards per machine; game allocations need separate networking.')
          ])
        ]), { parse_mode: 'HTML' });
        void monitorInstallation(message.chat.id, userId, row.id, row.name);
        return showScreen(message,
          note('INSTALL PANEL', 'Installation is now in progress.', 'Your credentials were sent in the message below.', 'Automatic progress updates will appear in this chat; use Install Status any time.'),
          [[{ text: 'Install Status', callback_data: `vps_istatus:${row.id}` }], BACK_ROW]);
      } catch (err) {
        return showScreen(message, note('INSTALL PANEL', 'Could not start installer.', safeError(err)), [BACK_ROW]);
      }
    }

    // ── create flow ──
    if (data === 'create_confirm') {
      if (!pendingCreates.has(userId)) return answer('This confirmation has expired.');
      pendingCreates.delete(userId);
      if (!isAdmin(userId) && !db.reserveCredits(userId)) {
        await answer('Not enough credits.');
        return showScreen(message, note('CREATE VPS', 'Insufficient credits.', 'Claim your daily reward first.'),
          [[{ text: 'Claim Daily 10', callback_data: 'menu_claim' }], BACK_ROW]);
      }
      await answer('Creating VPS…');
      await showScreen(message, note('CREATE VPS', 'Creating your Ubuntu 24.04 VPS…'), []);
      try {
        const boxd = await getBoxd(userKey(userId));
        const name = `tc-${userId.slice(-5)}-${Date.now().toString(36)}`.toLowerCase();
        const machine = await boxd.machines.create({
          name, image: 'ubuntu:24.04',
          config: { vcpu: config.defaultVcpu, memory: config.defaultMemory, ssh: true }
        });
        await boxd.machines.waitUntilReady(machine.id);
        const ready = await boxd.machines.get(machine.id);
        const m = normaliseMachine(ready || machine);
        db.saveMachine({
          id: m.id, telegram_id: userId, name: m.name, status: m.status,
          domain: m.domain, url: m.url, ssh_port: m.sshPort,
          vcpu: m.vcpu, memory_bytes: m.memoryBytes, created_at: new Date().toISOString()
        });
        return showScreen(message,
          frame('VPS CREATED', machineSections(m, [line('Credits charged', isAdmin(userId) ? '0 (Admin)' : config.vpsCost)])),
          [[{ text: 'Install Panel', callback_data: cbOk('vps_install', m.id) ? `vps_install:${m.id}` : 'menu_install' },
            { text: 'My VPS', callback_data: 'menu_vps' }], BACK_ROW]);
      } catch (err) {
        if (!isAdmin(userId)) db.refundCredits(userId);
        return showScreen(message, note('CREATE VPS',
          isAdmin(userId) ? 'VPS creation failed.' : `VPS creation failed. Your ${config.vpsCost} credits have been refunded.`,
          'Check Boxd for any partially created machine.', safeError(err)), [BACK_ROW]);
      }
    }

    await answer();
  } catch (err) {
    console.error('[callback error]', safeError(err));
    await answer('Something went wrong.');
  }
});

bot.onText(/^\/install(?:@\w+)?(?:\s+([A-Za-z0-9_-]+))?$/, async (msg, match) => {
  if (!privateOnly(msg)) return bot.sendMessage(msg.chat.id, 'Run /install in a private chat.');
  register(msg);
  const rows = db.listMachines(msg.from.id);
  const machineId = (match && match[1] || '').trim();
  const row = machineId ? db.getMachine(machineId, msg.from.id) : rows[0];
  if (!row) return bot.sendMessage(msg.chat.id, 'No owned VPS found. Create one first with /create.');
  const p = installPrompt(msg.from.id, row);
  return bot.sendMessage(msg.chat.id, p.text, { parse_mode: 'HTML', reply_markup: { inline_keyboard: p.rows } });
});

bot.onText(/^\/installstatus(?:@\w+)?(?:\s+([A-Za-z0-9_-]+))?$/, async (msg, match) => {
  if (!privateOnly(msg)) return;
  const rows = db.listMachines(msg.from.id);
  const machineId = (match && match[1] || '').trim();
  const row = machineId ? db.getMachine(machineId, msg.from.id) : rows[0];
  if (!row) return bot.sendMessage(msg.chat.id, 'No owned VPS found.');
  try {
    const output = await readStatus(userKey(msg.from.id), row.id);
    await bot.sendMessage(msg.chat.id,
      `Installer status — ${row.name}\n\n${output.replace(/```/g, '')}`);
  } catch (err) {
    await bot.sendMessage(msg.chat.id, `Could not read installer status.\n${safeError(err)}`);
  }
});

bot.onText(/^\/myvps(?:@\w+)?$/, async msg => {
  if (!privateOnly(msg)) return;
  register(msg);
  const rows = db.listMachines(msg.from.id);
  if (!rows.length) return bot.sendMessage(msg.chat.id, 'You have no VPS records yet. Use /create.');
  await bot.sendMessage(msg.chat.id, rows.map((m, i) =>
    `${i + 1}. ${m.name}\nID: ${m.id}\nStatus: ${m.status || 'unknown'}\nDomain: ${m.domain || 'Not reported'}`
  ).join('\n\n'));
});

bot.onText(/^\/status(?:@\w+)?(?:\s+(.+))?$/, async (msg, match) => {
  if (!privateOnly(msg)) return;
  register(msg);
  const rows = db.listMachines(msg.from.id);
  const machineId = (match && match[1] || '').trim();
  const row = machineId ? db.getMachine(machineId, msg.from.id) : rows[0];
  if (!row) return bot.sendMessage(msg.chat.id, 'Machine not found. Use /myvps to see your machine IDs.');
  try {
    const boxd = await getBoxd(userKey(msg.from.id));
    const m = normaliseMachine(await boxd.machines.get(row.id));
    db.updateMachine(m.status, m.domain, m.url, m.sshPort, m.vcpu, m.memoryBytes, row.id, String(msg.from.id));
    await bot.sendMessage(msg.chat.id, `*${md(m.name)}*\nID: \`${code(m.id)}\`\nStatus: ${md(m.status)}\nDefault domain: ${m.domain ? md(m.domain) : 'Not reported'}`, { parse_mode: 'Markdown' });
  } catch (err) {
    await bot.sendMessage(msg.chat.id, `Could not refresh machine status.\n${safeError(err)}`);
  }
});

bot.onText(/^\/adminstats(?:@\w+)?$/, async msg => {
  if (!privateOnly(msg) || !isAdmin(msg.from.id)) return;
  const s = db.stats();
  await bot.sendMessage(msg.chat.id, `Users: ${s.users}\nActive VPS: ${s.activeVps}\nTotal VPS records: ${s.totalVps}\nOwner: ${config.owner}`);
});

bot.on('polling_error', err => console.error('[Telegram polling error]', safeError(err)));
console.log(`[${config.botName}] running. Owner: ${config.owner}`);
