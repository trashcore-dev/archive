#!/usr/bin/env bash
set -Eeuo pipefail
umask 077
LOG=/tmp/trashcore-panel-wings-install.log
STATUS=/tmp/trashcore-panel-wings-install.status
PANEL_DIR=/var/www/pterodactyl
PANEL_VERSION=v1.15.2
THEME_REPO="${THEME_REPO:-https://github.com/Tennor-modz/Nightshift-.git}"
THEME_COMMIT="${THEME_COMMIT:-ecf1f9b5ee52bad7a0339d025c4e994a8f41f836}"
: "${PANEL_DOMAIN:?missing PANEL_DOMAIN}"
: "${WINGS_DOMAIN:?missing WINGS_DOMAIN}"
: "${PANEL_ADMIN_EMAIL:?missing PANEL_ADMIN_EMAIL}"
: "${PANEL_ADMIN_USERNAME:=admin}"
: "${PANEL_ADMIN_PASSWORD:?missing PANEL_ADMIN_PASSWORD}"
: "${SFTP_PUBLIC_PORT:?missing SFTP_PUBLIC_PORT}"
mkdir -p "$(dirname "$STATUS")"
exec 9>/tmp/trashcore-panel-wings-install.lock
flock -n 9 || { echo "Another installer process is already running."; exit 8; }
touch "$LOG"
chmod 644 "$LOG"
status(){ printf '%s | %s\n' "$(date -u +'%FT%TZ')" "$1" > "$STATUS"; chmod 644 "$STATUS"; echo "==> $1"; }
trap 'rc=$?; status "FAILED exit=$rc line=${BASH_LINENO[0]:-unknown}"; exit "$rc"' ERR
if [[ $EUID -ne 0 ]]; then echo "Root privileges required."; exit 77; fi
exec > >(tee -a "$LOG") 2>&1

status "Preflight"
. /etc/os-release
[[ "$ID" == ubuntu && "$VERSION_ID" == 24.04 ]] || { echo "Expected Ubuntu 24.04."; exit 2; }
[[ "$PANEL_DOMAIN" =~ ^[A-Za-z0-9.-]+$ && "$WINGS_DOMAIN" =~ ^[A-Za-z0-9.-]+$ ]] || exit 2
[[ "$THEME_COMMIT" =~ ^[0-9a-f]{40}$ ]] || { echo "THEME_COMMIT must be a full lowercase Git commit SHA."; exit 2; }
[[ ! -e "$PANEL_DIR/.env" && ! -d "$PANEL_DIR/app" ]] || { echo "Existing Panel detected; refusing overwrite."; exit 3; }
[[ $(df -Pm / | awk 'NR==2{print $4}') -ge 12000 ]] || { echo "Need at least 12GB free disk."; exit 5; }

status "Installing dependencies"
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y ca-certificates curl gnupg git tar unzip xz-utils cron nginx mariadb-server redis-server docker.io \
 php8.3 php8.3-cli php8.3-common php8.3-gd php8.3-mysql php8.3-mbstring php8.3-bcmath \
 php8.3-xml php8.3-fpm php8.3-curl php8.3-zip php8.3-intl php8.3-opcache php8.3-redis
systemctl enable --now mariadb redis-server php8.3-fpm nginx cron docker
command -v docker >/dev/null || { echo "Docker installation failed."; exit 4; }
docker info >/dev/null
docker run --rm hello-world >/dev/null

status "Installing Composer"
SIG="$(curl -fsSL https://composer.github.io/installer.sig)"
php -r "copy('https://getcomposer.org/installer','/tmp/composer-setup.php');"
ACTUAL="$(php -r "echo hash_file('sha384','/tmp/composer-setup.php');")"
[[ "$SIG" == "$ACTUAL" ]] || { echo "Composer signature mismatch."; exit 6; }
php /tmp/composer-setup.php --install-dir=/usr/local/bin --filename=composer
rm -f /tmp/composer-setup.php

status "Creating database"
DB_PASSWORD="$(openssl rand -hex 24)"
mariadb -uroot <<SQL
CREATE DATABASE IF NOT EXISTS panel CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS 'pterodactyl'@'127.0.0.1' IDENTIFIED BY '${DB_PASSWORD}';
ALTER USER 'pterodactyl'@'127.0.0.1' IDENTIFIED BY '${DB_PASSWORD}';
GRANT ALL PRIVILEGES ON panel.* TO 'pterodactyl'@'127.0.0.1';
FLUSH PRIVILEGES;
SQL

status "Downloading Pterodactyl ${PANEL_VERSION}"
mkdir -p "$PANEL_DIR"
cd "$PANEL_DIR"
curl -fL --retry 3 "https://github.com/pterodactyl/panel/releases/download/${PANEL_VERSION}/panel.tar.gz" -o /tmp/panel.tar.gz
tar -tzf /tmp/panel.tar.gz >/dev/null
tar -xzf /tmp/panel.tar.gz -C "$PANEL_DIR"
test -f artisan && test -f .env.example
chmod -R 755 storage bootstrap/cache

status "Configuring Panel"
cp .env.example .env
APP_KEY="$(php artisan key:generate --show --no-ansi)"
set_env(){
  local k="$1" v="$2"
  if grep -q "^${k}=" .env; then
    sed -i "s|^${k}=.*|${k}=${v}|" .env
  else
    printf '%s=%s\n' "$k" "$v" >> .env
  fi
}
set_env APP_ENV production
set_env APP_DEBUG false
set_env APP_KEY "$APP_KEY"
set_env APP_URL "https://${PANEL_DOMAIN}"
set_env APP_TIMEZONE Africa/Nairobi
set_env APP_SERVICE_AUTHOR "$PANEL_ADMIN_EMAIL"
set_env DB_CONNECTION mysql
set_env DB_HOST 127.0.0.1
set_env DB_PORT 3306
set_env DB_DATABASE panel
set_env DB_USERNAME pterodactyl
set_env DB_PASSWORD "$DB_PASSWORD"
set_env CACHE_DRIVER redis
set_env SESSION_DRIVER redis
set_env QUEUE_CONNECTION redis
set_env REDIS_HOST 127.0.0.1
set_env REDIS_PASSWORD null
set_env REDIS_PORT 6379
set_env MAIL_MAILER log
set_env TRUSTED_PROXIES '*'
set_env PTERODACTYL_TELEMETRY_ENABLED false

status "Installing Panel dependencies"
COMPOSER_ALLOW_SUPERUSER=1 composer install --no-dev --optimize-autoloader --no-interaction --prefer-dist
composer check-platform-reqs --no-dev
php artisan config:clear
php artisan migrate --seed --force
php artisan p:user:make --email="$PANEL_ADMIN_EMAIL" --username="$PANEL_ADMIN_USERNAME" \
 --name-first=Trashcore --name-last=Admin --password="$PANEL_ADMIN_PASSWORD" --admin=1 --no-interaction

status "Configuring Nginx"
cat > /etc/nginx/sites-available/pterodactyl.conf <<NGINX
server {
 listen 80 default_server;
 listen [::]:80 default_server;
 server_name ${PANEL_DOMAIN};
 root ${PANEL_DIR}/public;
 index index.php;
 charset utf-8;
 client_max_body_size 100m;
 location / { try_files \$uri \$uri/ /index.php?\$query_string; }
 location ~ \\.php$ {
  fastcgi_split_path_info ^(.+\\.php)(/.+)$;
  fastcgi_pass unix:/run/php/php8.3-fpm.sock;
  fastcgi_index index.php;
  include fastcgi_params;
  fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
  fastcgi_param HTTP_PROXY "";
  fastcgi_read_timeout 300;
 }
 location ~ /\\. { deny all; }
}
NGINX
rm -f /etc/nginx/sites-enabled/default
ln -sfn /etc/nginx/sites-available/pterodactyl.conf /etc/nginx/sites-enabled/pterodactyl.conf
nginx -t
systemctl reload nginx

status "Applying Nightshift"
status "Building the Nightshift release archive"
THEME_DIR=/opt/Nightshift
rm -rf "$THEME_DIR"
git init "$THEME_DIR"
git -C "$THEME_DIR" remote add origin "$THEME_REPO"
git -C "$THEME_DIR" fetch --depth 1 origin "$THEME_COMMIT"
git -C "$THEME_DIR" checkout --detach FETCH_HEAD
[[ "$(git -C "$THEME_DIR" rev-parse HEAD)" == "$THEME_COMMIT" ]]
grep -q "'version' => '1.15.2'" "$THEME_DIR/config/app.php" || { echo "Pinned Nightshift source does not match Panel 1.15.2."; exit 21; }
curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
apt-get install -y nodejs
npm install -g yarn@1.22.22
cd "$THEME_DIR"
yarn install --frozen-lockfile
mkdir -p public/assets
NODE_OPTIONS=--openssl-legacy-provider yarn build:production
chmod +x ./release.sh
env NODE_OPTIONS=--openssl-legacy-provider ./release.sh
THEME_ARCHIVE="$THEME_DIR/release/panel.tar.gz"
[[ -s "$THEME_ARCHIVE" ]] || { echo "Nightshift release.sh did not create release/panel.tar.gz."; exit 21; }
tar -tzf "$THEME_ARCHIVE" >/dev/null

status "Applying Nightshift to the installed Panel"
BACKUP="/root/nightshift-backup-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP"
cp -a "$PANEL_DIR/resources" "$BACKUP/resources"
cp -a "$PANEL_DIR/tailwind.config.js" "$BACKUP/" 2>/dev/null || true
cd "$PANEL_DIR"
php artisan down || true
tar -xzf "$THEME_ARCHIVE" -C "$PANEL_DIR" --exclude='./.env' --exclude='./storage' --exclude='./storage/*'
COMPOSER_ALLOW_SUPERUSER=1 composer install --no-dev --optimize-autoloader --no-interaction --prefer-dist
yarn install --frozen-lockfile
if [[ -f "$PANEL_DIR/resources/scripts/theme.ts" && -d "$PANEL_DIR/resources/scripts/theme" ]]; then
 mv "$PANEL_DIR/resources/scripts/theme.ts" "$BACKUP/theme.ts.old"
fi
status "Building production assets with Nightshift"
env NODE_OPTIONS=--openssl-legacy-provider yarn build:production
php artisan up
php artisan optimize:clear
php artisan queue:restart
chown -R www-data:www-data "$PANEL_DIR"
chmod -R 755 "$PANEL_DIR/storage" "$PANEL_DIR/bootstrap/cache"

status "Configuring queue and scheduler"
cat > /etc/systemd/system/pteroq.service <<'SERVICE'
[Unit]
Description=Pterodactyl Queue Worker
After=redis-server.service
[Service]
User=www-data
Group=www-data
Restart=always
ExecStart=/usr/bin/php /var/www/pterodactyl/artisan queue:work --queue=high,standard,low --sleep=3 --tries=3
RestartSec=5
[Install]
WantedBy=multi-user.target
SERVICE
systemctl daemon-reload
systemctl enable --now pteroq
(crontab -l 2>/dev/null | grep -v '/var/www/pterodactyl/artisan schedule:run' || true; \
 echo '* * * * * php /var/www/pterodactyl/artisan schedule:run >> /dev/null 2>&1') | crontab -

status "Installing Wings"
install -d -m 755 /etc/pterodactyl /var/lib/pterodactyl/volumes
case "$(uname -m)" in x86_64) WARCH=amd64;; aarch64|arm64) WARCH=arm64;; *) echo "Unsupported CPU architecture"; exit 22;; esac
curl -fL --retry 3 "https://github.com/pterodactyl/wings/releases/latest/download/wings_linux_${WARCH}" -o /usr/local/bin/wings
chmod 755 /usr/local/bin/wings

status "Creating Panel node and Wings config"
LOC_SHORT="bx$(date +%s | tail -c 5)"
php artisan p:location:make --short="$LOC_SHORT" --long="Boxd Machine" --no-interaction
LOCATION_ID="$(mariadb -N -uroot panel -e "SELECT id FROM locations WHERE short='${LOC_SHORT}' LIMIT 1;")"
[[ "$LOCATION_ID" =~ ^[0-9]+$ ]]
MEM_MB="$(awk '/MemTotal/ {print int($2/1024)}' /proc/meminfo)"
NODE_MEM="$((MEM_MB-1024))"
DISK_MB="$(df -Pm / | awk 'NR==2{print $2}')"
NODE_DISK="$((DISK_MB-4096))"
(( NODE_MEM > 512 && NODE_DISK > 4096 ))
php artisan p:node:make \
 --name="Boxd-$(hostname -s)" --description="Single-machine Panel and Wings" \
 --locationId="$LOCATION_ID" --fqdn="$WINGS_DOMAIN" --public=1 --scheme=https \
 --proxy=1 --maintenance=0 --maxMemory="$NODE_MEM" --overallocateMemory=0 \
 --maxDisk="$NODE_DISK" --overallocateDisk=0 --uploadSize=100 \
 --daemonListeningPort=443 --daemonSFTPPort="$SFTP_PUBLIC_PORT" \
 --daemonBase=/var/lib/pterodactyl/volumes --no-interaction
NODE_ID="$(mariadb -N -uroot panel -e "SELECT id FROM nodes WHERE fqdn='${WINGS_DOMAIN}' ORDER BY id DESC LIMIT 1;")"
[[ "$NODE_ID" =~ ^[0-9]+$ ]]
php artisan p:node:configuration "$NODE_ID" > /etc/pterodactyl/config.yml
test -s /etc/pterodactyl/config.yml
# Boxd maps a public TCP port to the guest's fixed SFTP port 2022.
# The Panel advertises the Boxd public port, while Wings listens internally on 2022.
sed -i '/^api:/,/^[^ ]/ s/^  port:.*/  port: 8080/' /etc/pterodactyl/config.yml
sed -i '/^  ssl:/,/^[^ ]/ s/^    enabled:.*/    enabled: false/' /etc/pterodactyl/config.yml
sed -i '/^  sftp:/,/^[^ ]/ s/^    bind_port:.*/    bind_port: 2022/' /etc/pterodactyl/config.yml
grep -q '^  port: 8080$' /etc/pterodactyl/config.yml
grep -q '^    bind_port: 2022$' /etc/pterodactyl/config.yml

cat > /etc/systemd/system/wings.service <<'SERVICE'
[Unit]
Description=Pterodactyl Wings Daemon
After=docker.service
Requires=docker.service
[Service]
User=root
WorkingDirectory=/etc/pterodactyl
LimitNOFILE=4096
ExecStart=/usr/local/bin/wings
Restart=on-failure
RestartSec=5s
[Install]
WantedBy=multi-user.target
SERVICE
mkdir -p /var/run/wings
systemctl daemon-reload
systemctl enable --now wings

status "Verifying local services"
for unit in nginx mariadb redis-server pteroq wings docker; do systemctl is-active --quiet "$unit"; done
PANEL_CODE="$(curl -sS -o /dev/null -w '%{http_code}' -H "Host: ${PANEL_DOMAIN}" http://127.0.0.1/)"
[[ "$PANEL_CODE" == 200 || "$PANEL_CODE" == 302 ]]
WINGS_CODE="$(curl -sS -o /dev/null -w '%{http_code}' http://127.0.0.1:8080/api/system || true)"
[[ "$WINGS_CODE" == 401 || "$WINGS_CODE" == 403 || "$WINGS_CODE" == 200 ]]
status "COMPLETE: local Panel and Wings services installed. Verify public Boxd HTTPS proxy and console WebSocket."
echo "PANEL_URL=https://${PANEL_DOMAIN}"
echo "WINGS_URL=https://${WINGS_DOMAIN}:443"
echo "NODE_ID=${NODE_ID}"
echo "SFTP_PUBLIC_PORT=${SFTP_PUBLIC_PORT}"
echo "ADMIN_EMAIL=${PANEL_ADMIN_EMAIL}"
echo "ADMIN_USERNAME=${PANEL_ADMIN_USERNAME}"
echo "THEME_BACKUP=${BACKUP}"
echo "NOTE=Game allocations are not auto-created; Boxd raw TCP/UDP forwards are limited to three per machine."
