require('dotenv').config();

const required = ['BOT_TOKEN', 'MASTER_KEY', 'ADMIN_IDS'];
for (const key of required) {
  if (!process.env[key]) throw new Error(`Missing ${key}. Copy .env.example to .env and configure it.`);
}
if (!/^[a-fA-F0-9]{64}$/.test(process.env.MASTER_KEY)) {
  throw new Error('MASTER_KEY must be exactly 64 hexadecimal characters (32 bytes).');
}
const adminIds = process.env.ADMIN_IDS.split(',').map(x => x.trim()).filter(Boolean);
if (!adminIds.length || adminIds.some(id => !/^\d+$/.test(id))) {
  throw new Error('ADMIN_IDS must contain one or more comma-separated Telegram numeric user IDs.');
}

module.exports = {
  botToken: process.env.BOT_TOKEN,
  masterKey: Buffer.from(process.env.MASTER_KEY, 'hex'),
  botName: process.env.BOT_NAME || 'TRASHCORE BOXD MANAGER',
  dbPath: process.env.DB_PATH || './database.sqlite',
  defaultVcpu: Number(process.env.DEFAULT_VCPU || 2),
  defaultMemory: process.env.DEFAULT_MEMORY || '8G',
  boxdApiKey: (process.env.BOXD_API_KEY || '').trim(),
  adminIds,
  owner: '@trashcoredev2',
  initialCredits: 10,
  vpsCost: 100,
  dailyReward: 10,
  menuImage: require('path').join(__dirname, 'assets', 'menu-image.png')
};
