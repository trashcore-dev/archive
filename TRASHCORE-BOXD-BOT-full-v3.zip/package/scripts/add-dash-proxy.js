// Usage: node scripts/add-dash-proxy.js <machine-name> [region=fra] [port=3000]
// Adds (or updates) a Boxd HTTPS proxy named "dash" that forwards to the Mini App port,
// then prints the URL to put in WEBAPP_URL. Uses the same SDK calls as lib/installer.js.
require('dotenv').config();
const { getBoxd } = require('../lib/boxd');

(async () => {
  const [name, region = 'fra', portArg = '3000'] = process.argv.slice(2);
  const port = Number(portArg);
  if (!name || !Number.isInteger(port)) { console.error('Usage: node scripts/add-dash-proxy.js <machine-name> [region] [port]'); process.exit(1); }
  const boxd = await getBoxd(process.env.BOXD_API_KEY, region);
  try {
    let routes = await boxd.machines.proxies.list(name);
    if (routes.find(route => route.name === 'dash')) await boxd.machines.proxies.setPort(name, port, { name: 'dash' });
    else await boxd.machines.proxies.create(name, 'dash', port);
    routes = await boxd.machines.proxies.list(name);
    const dash = routes.find(route => route.name === 'dash');
    if (!dash || !dash.domain) throw new Error('Boxd did not return the dash proxy domain.');
    console.log(`WEBAPP_URL=https://${dash.domain}`);
  } finally {
    if (boxd.close) await boxd.close().catch(() => {});
  }
})().catch(err => { console.error('Failed:', String(err && err.message || err).replace(/bxd_[A-Za-z0-9_-]+/g, '[redacted]')); process.exit(1); });
