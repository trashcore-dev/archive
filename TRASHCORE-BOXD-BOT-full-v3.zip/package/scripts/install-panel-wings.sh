#!/usr/bin/env bash
set -Eeuo pipefail
umask 077
LOG=/tmp/trashcore-panel-wings-install.log
STATUS=/tmp/trashcore-panel-wings-install.status
PANEL_DIR=/var/www/pterodactyl
STACK_DIR=/opt/trashcore-panel-stack
PANEL_VERSION=v1.15.2
THEME_REPO="${THEME_REPO:-https://github.com/Tennor-modz/Nightshift-.git}"
THEME_COMMIT="${THEME_COMMIT:-ecf1f9b5ee52bad7a0339d025c4e994a8f41f836}"
REMOTE_COMPOSE_TEMPLATE=/tmp/trashcore-panel-stack.compose.yml
REMOTE_DOCKERFILE_TEMPLATE=/tmp/trashcore-panel-runtime.Dockerfile
: "${PANEL_ADMIN_USERNAME:=admin}"
status(){ printf '%s | %s\n' "$(date -u +'%FT%TZ')" "$1" > "$STATUS"; chmod 644 "$STATUS"; echo "==> $1"; }
trap 'rc=$?; if (( rc != 0 )); then status "FAILED exit=$rc line=${BASH_LINENO[0]:-unknown}"; fi' EXIT
mkdir -p "$(dirname "$STATUS")"
touch "$LOG"
chmod 644 "$LOG"
exec > >(tee -a "$LOG") 2>&1

status "Preflight"
for variable in PANEL_DOMAIN WINGS_DOMAIN PANEL_ADMIN_EMAIL PANEL_ADMIN_PASSWORD SFTP_PUBLIC_PORT; do
  if [[ -z "${!variable:-}" ]]; then
    echo "Missing required environment variable: $variable"
    status "FAILED: Missing required environment variable $variable"
    exit 2
  fi
done
if [[ $EUID -ne 0 ]]; then
  echo "Root privileges required."
  status "FAILED: Root privileges required."
  exit 77
fi
[[ "$SFTP_PUBLIC_PORT" =~ ^[0-9]+$ ]] && (( SFTP_PUBLIC_PORT > 0 && SFTP_PUBLIC_PORT <= 65535 )) || { echo "SFTP_PUBLIC_PORT must be a TCP port number."; exit 2; }
[[ -s "$REMOTE_COMPOSE_TEMPLATE" ]] || { echo "Missing uploaded Docker Compose template: $REMOTE_COMPOSE_TEMPLATE"; exit 2; }
[[ -s "$REMOTE_DOCKERFILE_TEMPLATE" ]] || { echo "Missing uploaded PHP runtime Dockerfile: $REMOTE_DOCKERFILE_TEMPLATE"; exit 2; }
exec 9>/tmp/trashcore-panel-wings-install.lock
if ! flock -n 9; then
  echo "Another installer process is already running."
  status "FAILED: Another installer process is already running."
  exit 8
fi
. /etc/os-release
[[ "$ID" == ubuntu && "$VERSION_ID" == 24.04 ]] || { echo "Expected Ubuntu 24.04."; exit 2; }
[[ "$PANEL_DOMAIN" =~ ^[A-Za-z0-9.-]+$ && "$WINGS_DOMAIN" =~ ^[A-Za-z0-9.-]+$ ]] || exit 2
[[ "$THEME_COMMIT" =~ ^[0-9a-f]{40}$ ]] || { echo "THEME_COMMIT must be a full lowercase Git commit SHA."; exit 2; }
[[ ! -e "$PANEL_DIR/.env" && ! -d "$PANEL_DIR/app" ]] || { echo "Existing Panel detected; refusing overwrite."; exit 3; }
[[ ! -e "$STACK_DIR" ]] || { echo "Existing Trashcore Docker stack detected; refusing overwrite."; exit 3; }
[[ $(df -Pm / | awk 'NR==2{print $4}') -ge 12000 ]] || { echo "Need at least 12GB free disk."; exit 5; }
ensure_docker_compose_v2(){
  local help_output
  if ! help_output="$(docker --help 2>&1)"; then
    echo "Unable to inspect the Docker CLI for the Compose v2 plugin."
    return 1
  fi
  if ! grep -Eq '^[[:space:]]+compose\*?[[:space:]]' <<<"$help_output"; then
    echo "Docker Compose v2 is missing; installing Ubuntu 24.04 package docker-compose-v2."
    if ! apt-get update; then
      echo "Could not update apt indexes to install Docker Compose v2."
      return 1
    fi
    if ! apt-get install -y docker-compose-v2; then
      echo "Could not install Ubuntu package docker-compose-v2; Docker Compose v2 is required."
      return 1
    fi
  fi
  if ! docker compose version; then
    echo "Docker Compose v2 is unavailable after checking or installing docker-compose-v2."
    return 1
  fi
}
command -v docker >/dev/null || { echo "Boxd's Docker Engine is unavailable; refusing an unmanaged install."; exit 4; }
if ! ensure_docker_compose_v2; then
  status "FAILED: Docker Compose v2 unavailable."
  exit 4
fi
docker info >/dev/null
docker run --rm hello-world >/dev/null

dc(){ docker compose --project-directory "$STACK_DIR" -f "$STACK_DIR/compose.yml" "$@"; }
run_panel_php(){ dc run --rm --no-deps --user 33:33 --entrypoint php panel-php "$@"; }
run_composer(){ dc run --rm --no-deps --user 33:33 --entrypoint composer panel-php "$@"; }
db_root_query(){
  local sql="$1"
  dc exec -T database sh -lc 'MYSQL_PWD="$MARIADB_ROOT_PASSWORD" exec mariadb -N -uroot panel -e "$1"' query "$sql"
}
wait_for_healthy(){
  local service="$1" id state health attempt
  id="$(dc ps -q "$service")"
  [[ -n "$id" ]] || { echo "No container was created for $service."; return 1; }
  for attempt in $(seq 1 90); do
    state="$(docker inspect --format '{{.State.Status}}' "$id" 2>/dev/null || true)"
    health="$(docker inspect --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}' "$id" 2>/dev/null || true)"
    [[ "$health" == healthy ]] && return 0
    if [[ "$state" == exited || "$state" == dead ]]; then
      docker logs --tail 40 "$id" >&2 || true
      echo "$service container stopped in state $state."
      return 1
    fi
    sleep 2
  done
  docker logs --tail 40 "$id" >&2 || true
  echo "Timed out waiting for $service to become healthy (last state=$state, health=$health)."
  return 1
}
verify_restart_policy(){
  local service="$1" id policy
  id="$(dc ps -q "$service")"
  [[ -n "$id" ]] || { echo "No running container for $service."; return 1; }
  policy="$(docker inspect --format '{{.HostConfig.RestartPolicy.Name}}' "$id")"
  [[ "$policy" == always ]] || { echo "$service has restart policy '$policy', expected 'always'."; return 1; }
}
wait_for_http_code(){
  local label="$1" url="$2" host_header="$3" accepted="$4" id code attempt
  id="$(dc ps -q "${label}")"
  for attempt in $(seq 1 30); do
    code="$(curl -sS --max-time 5 -o /dev/null -w '%{http_code}' ${host_header:+-H "$host_header"} "$url" 2>/dev/null || true)"
    case " $accepted " in *" $code "*) return 0;; esac
    sleep 2
  done
  [[ -z "$id" ]] || docker logs --tail 60 "$id" >&2 || true
  echo "$label did not return an expected HTTP status from $url (last status: ${code:-none})."
  return 1
}

status "Installing host build tools"
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y ca-certificates curl gnupg git tar unzip xz-utils openssl

status "Preparing Docker-managed service stack"
install -d -m 700 "$STACK_DIR" "$STACK_DIR/runtime"
install -m 600 "$REMOTE_COMPOSE_TEMPLATE" "$STACK_DIR/compose.yml"
install -m 644 "$REMOTE_DOCKERFILE_TEMPLATE" "$STACK_DIR/runtime/Dockerfile"
DB_PASSWORD="$(openssl rand -hex 24)"
DB_ROOT_PASSWORD="$(openssl rand -hex 24)"
cat > "$STACK_DIR/.env" <<EOF
MARIADB_ROOT_PASSWORD=${DB_ROOT_PASSWORD}
MARIADB_PASSWORD=${DB_PASSWORD}
EOF
chmod 600 "$STACK_DIR/.env"
dc config --quiet

status "Building the Panel PHP runtime"
dc build panel-php

status "Starting persistent database and cache containers"
dc up -d database redis
wait_for_healthy database
wait_for_healthy redis

status "Downloading Pterodactyl ${PANEL_VERSION}"
mkdir -p "$PANEL_DIR"
cd "$PANEL_DIR"
curl -fL --retry 3 "https://github.com/pterodactyl/panel/releases/download/${PANEL_VERSION}/panel.tar.gz" -o /tmp/panel.tar.gz
tar -tzf /tmp/panel.tar.gz >/dev/null
tar -xzf /tmp/panel.tar.gz -C "$PANEL_DIR"
test -f artisan && test -f .env.example
chmod -R 755 storage bootstrap/cache
chown -R 33:33 "$PANEL_DIR"

status "Configuring Panel"
cp .env.example .env
chown 33:33 .env
chmod 640 .env
APP_KEY="$(run_panel_php artisan key:generate --show --no-ansi)"
set_env(){
  local k="$1" v="$2"
  if grep -q "^${k}=" .env; then
    sed -i "s|^${k}=.*|${k}=${v}|" .env
  else
    printf '%s=%s\n' "$k" "$v" >> .env
  fi
}
set_env APP_ENV production
set_env APP_DEBUG false
set_env APP_KEY "$APP_KEY"
set_env APP_URL "https://${PANEL_DOMAIN}"
set_env APP_TIMEZONE Africa/Nairobi
set_env APP_SERVICE_AUTHOR "$PANEL_ADMIN_EMAIL"
set_env DB_CONNECTION mysql
set_env DB_HOST database
set_env DB_PORT 3306
set_env DB_DATABASE panel
set_env DB_USERNAME pterodactyl
set_env DB_PASSWORD "$DB_PASSWORD"
set_env CACHE_DRIVER redis
set_env SESSION_DRIVER redis
set_env QUEUE_CONNECTION redis
set_env REDIS_HOST redis
set_env REDIS_PASSWORD null
set_env REDIS_PORT 6379
set_env MAIL_MAILER log
set_env TRUSTED_PROXIES '*'
set_env PTERODACTYL_TELEMETRY_ENABLED false
chown -R 33:33 "$PANEL_DIR"
chmod 640 "$PANEL_DIR/.env"

status "Installing Panel dependencies"
run_composer install --no-dev --optimize-autoloader --no-interaction --prefer-dist
run_composer check-platform-reqs --no-dev
run_panel_php artisan config:clear
run_panel_php artisan migrate --seed --force
run_panel_php artisan p:user:make --email="$PANEL_ADMIN_EMAIL" --username="$PANEL_ADMIN_USERNAME" \
 --name-first=Trashcore --name-last=Admin --password="$PANEL_ADMIN_PASSWORD" --admin=1 --no-interaction

status "Configuring Nginx container"
cat > "$STACK_DIR/nginx.conf" <<NGINX
server {
 listen 80 default_server;
 listen [::]:80 default_server;
 server_name ${PANEL_DOMAIN};
 root ${PANEL_DIR}/public;
 index index.php;
 charset utf-8;
 client_max_body_size 100m;
 location / { try_files \$uri \$uri/ /index.php?\$query_string; }
 location ~ \\.php$ {
  fastcgi_split_path_info ^(.+\\.php)(/.+)$;
  fastcgi_pass panel-php:9000;
  fastcgi_index index.php;
  include fastcgi_params;
  fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
  fastcgi_param HTTP_PROXY "";
  fastcgi_read_timeout 300;
 }
 location ~ /\\. { deny all; }
}
NGINX
chmod 644 "$STACK_DIR/nginx.conf"
dc run --rm --no-deps --entrypoint nginx panel-nginx -t

status "Applying Nightshift"
status "Building the Nightshift release archive"
THEME_DIR=/opt/Nightshift
rm -rf "$THEME_DIR"
git init "$THEME_DIR"
git -C "$THEME_DIR" remote add origin "$THEME_REPO"
git -C "$THEME_DIR" fetch --depth 1 origin "$THEME_COMMIT"
git -C "$THEME_DIR" checkout --detach FETCH_HEAD
[[ "$(git -C "$THEME_DIR" rev-parse HEAD)" == "$THEME_COMMIT" ]]
grep -q "'version' => '1.15.2'" "$THEME_DIR/config/app.php" || { echo "Pinned Nightshift source does not match Panel 1.15.2."; exit 21; }
curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
apt-get install -y nodejs
npm install -g yarn@1.22.22
cd "$THEME_DIR"
yarn install --frozen-lockfile
mkdir -p public/assets
NODE_OPTIONS=--openssl-legacy-provider yarn build:production
chmod +x ./release.sh
env NODE_OPTIONS=--openssl-legacy-provider ./release.sh
THEME_ARCHIVE="$THEME_DIR/release/panel.tar.gz"
[[ -s "$THEME_ARCHIVE" ]] || { echo "Nightshift release.sh did not create release/panel.tar.gz."; exit 21; }
tar -tzf "$THEME_ARCHIVE" >/dev/null

status "Applying Nightshift to the installed Panel"
BACKUP="/root/nightshift-backup-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP"
cp -a "$PANEL_DIR/resources" "$BACKUP/resources"
cp -a "$PANEL_DIR/tailwind.config.js" "$BACKUP/" 2>/dev/null || true
cd "$PANEL_DIR"
run_panel_php artisan down || true
tar -xzf "$THEME_ARCHIVE" -C "$PANEL_DIR" --exclude='./.env' --exclude='./storage' --exclude='./storage/*'
chown -R 33:33 "$PANEL_DIR"
run_composer install --no-dev --optimize-autoloader --no-interaction --prefer-dist
yarn install --frozen-lockfile
if [[ -f "$PANEL_DIR/resources/scripts/theme.ts" && -d "$PANEL_DIR/resources/scripts/theme" ]]; then
 mv "$PANEL_DIR/resources/scripts/theme.ts" "$BACKUP/theme.ts.old"
fi
status "Building production assets with Nightshift"
env NODE_OPTIONS=--openssl-legacy-provider yarn build:production
run_panel_php artisan up
run_panel_php artisan optimize:clear
run_panel_php artisan queue:restart
chown -R 33:33 "$PANEL_DIR"
chmod -R 755 "$PANEL_DIR/storage" "$PANEL_DIR/bootstrap/cache"
chmod 640 "$PANEL_DIR/.env"

status "Configuring Panel node and Wings"
install -d -m 755 /etc/pterodactyl /var/lib/pterodactyl/volumes /var/log/pterodactyl /tmp/pterodactyl /run/wings
LOC_SHORT="bx$(date +%s | tail -c 5)"
run_panel_php artisan p:location:make --short="$LOC_SHORT" --long="Boxd Machine" --no-interaction
LOCATION_ID="$(db_root_query "SELECT id FROM locations WHERE short='${LOC_SHORT}' LIMIT 1;")"
[[ "$LOCATION_ID" =~ ^[0-9]+$ ]]
MEM_MB="$(awk '/MemTotal/ {print int($2/1024)}' /proc/meminfo)"
NODE_MEM="$((MEM_MB-1024))"
DISK_MB="$(df -Pm / | awk 'NR==2{print $2}')"
NODE_DISK="$((DISK_MB-4096))"
(( NODE_MEM > 512 && NODE_DISK > 4096 ))
run_panel_php artisan p:node:make \
 --name="Boxd-$(hostname -s)" --description="Single-machine Panel and Wings" \
 --locationId="$LOCATION_ID" --fqdn="$WINGS_DOMAIN" --public=1 --scheme=https \
 --proxy=1 --maintenance=0 --maxMemory="$NODE_MEM" --overallocateMemory=0 \
 --maxDisk="$NODE_DISK" --overallocateDisk=0 --uploadSize=100 \
 --daemonListeningPort=443 --daemonSFTPPort="$SFTP_PUBLIC_PORT" \
 --daemonBase=/var/lib/pterodactyl/volumes --no-interaction
NODE_ID="$(db_root_query "SELECT id FROM nodes WHERE fqdn='${WINGS_DOMAIN}' ORDER BY id DESC LIMIT 1;")"
[[ "$NODE_ID" =~ ^[0-9]+$ ]]
run_panel_php artisan p:node:configuration "$NODE_ID" > /etc/pterodactyl/config.yml
test -s /etc/pterodactyl/config.yml
chmod 600 /etc/pterodactyl/config.yml
# Boxd maps a public TCP port to the guest's fixed SFTP port 2022.
# The Panel advertises the Boxd public port, while Wings listens internally on 2022.
sed -i '/^api:/,/^[^ ]/ s/^  port:.*/  port: 8080/' /etc/pterodactyl/config.yml
sed -i '/^  ssl:/,/^[^ ]/ s/^    enabled:.*/    enabled: false/' /etc/pterodactyl/config.yml
sed -i '/^  sftp:/,/^[^ ]/ s/^    bind_port:.*/    bind_port: 2022/' /etc/pterodactyl/config.yml
grep -q '^  port: 8080$' /etc/pterodactyl/config.yml
grep -q '^    bind_port: 2022$' /etc/pterodactyl/config.yml

status "Starting Docker-managed Panel and Wings services"
dc up -d --build panel-php panel-nginx panel-queue panel-scheduler wings
for service in database redis panel-php panel-nginx panel-queue panel-scheduler wings; do
  verify_restart_policy "$service"
done
wait_for_healthy database
wait_for_healthy redis
wait_for_healthy panel-php
wait_for_healthy panel-nginx
for service in panel-queue panel-scheduler wings; do
  id="$(dc ps -q "$service")"
  [[ -n "$id" ]] || { echo "$service did not remain running."; exit 1; }
  state="$(docker inspect --format '{{.State.Status}}' "$id")"
  [[ "$state" == running ]] || { docker logs --tail 60 "$id" >&2 || true; echo "$service is not running (state=$state)."; exit 1; }
done
PANEL_CODE="$(curl -sS --max-time 10 -o /dev/null -w '%{http_code}' -H "Host: ${PANEL_DOMAIN}" http://127.0.0.1/ || true)"
[[ "$PANEL_CODE" == 200 || "$PANEL_CODE" == 302 ]] || { docker logs --tail 60 "$(dc ps -q panel-nginx)" >&2 || true; echo "Panel returned HTTP ${PANEL_CODE:-no response}."; exit 1; }
WINGS_CODE="$(curl -sS --max-time 10 -o /dev/null -w '%{http_code}' http://127.0.0.1:8080/api/system || true)"
[[ "$WINGS_CODE" == 401 || "$WINGS_CODE" == 403 || "$WINGS_CODE" == 200 ]] || { docker logs --tail 60 "$(dc ps -q wings)" >&2 || true; echo "Wings API returned HTTP ${WINGS_CODE:-no response}."; exit 1; }
status "COMPLETE: Docker-managed Panel and Wings containers are running; verify public Boxd HTTPS proxy and console WebSocket."
echo "PANEL_URL=https://${PANEL_DOMAIN}"
echo "WINGS_URL=https://${WINGS_DOMAIN}:443"
echo "NODE_ID=${NODE_ID}"
echo "SFTP_PUBLIC_PORT=${SFTP_PUBLIC_PORT}"
echo "ADMIN_EMAIL=${PANEL_ADMIN_EMAIL}"
echo "ADMIN_USERNAME=${PANEL_ADMIN_USERNAME}"
echo "THEME_BACKUP=${BACKUP}"
echo "SERVICE_MANAGER=Docker restart policies (Boxd documents Docker starting at boot); no systemd dependency."
echo "NOTE=Game allocations are not auto-created; Boxd raw TCP/UDP forwards are limited to three per machine."
