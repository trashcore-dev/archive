# TRASHCORE VPS BOT

A Telegram bot for creating and managing Boxd VPS machines and starting a Pterodactyl Panel + Wings installation. It is written for Node.js 24 and uses SQLite for users, coin balances, and VPS ownership. The welcome image is `assets/trashcore-vps-welcome.png`.

## Quick setup

1. Create a Telegram bot and copy `.env.example` to `.env`.
2. Set `BOT_TOKEN`, `BOXD_API_KEY`, and `ADMIN_IDS` in `.env`. `ADMIN_IDS` is a comma-separated list of Telegram numeric user IDs. Keep `.env` private; it is ignored by Git and excluded from the project ZIP.
3. Install and run with Node 24:

   ```bash
   npm ci
   npm test
   npm start
   ```

The SQLite database is created at `DB_PATH` (default `./database.sqlite`). It stores user balances and VPS metadata, not Boxd API keys. Set `INITIAL_CREDITS` only if you intentionally want a starting balance; it defaults to zero. Users earn 10 coins once per Africa/Nairobi calendar day. Non-admin VPS creation costs 100 bot coins; `ADMIN_IDS` users create without a bot-coin charge.

## What the bot offers

The `/start` message uses the generated banner and includes bot uptime, registered-user count, Boxd remaining quota, the user’s coin balance, and East Africa date/time. Telegram does not allow bots to set actual inline-keyboard button colors; the menu uses a consistent emoji palette and labels instead.

VPS creation lets the user choose one of Boxd’s documented sizes (1 vCPU/4 GiB, 2/8 GiB, 4/16 GiB, or 8/32 GiB), an organization-enabled Boxd region, and Ubuntu 24.04. A provisioning failure refunds the 100 bot coins. This bot-coin ledger is separate from Boxd billing: machines are created under the `BOXD_API_KEY` owner and any Boxd usage charges go to that Boxd account. The live quota call reads `maxVms` and `vmCount`; the display is explicitly a quota remainder, not physical inventory.

`Manage VPS` shows machine state, Boxd hostname, public IP (resolved from the machine hostname), SSH port, region, web URL, and Boxd-reported cumulative running time when the API key can read machine usage. For a custom domain, the bot prints the exact apex A and wildcard CNAME records, waits for the user to tap “DNS is set — verify”, and checks both records against public DNS before calling Boxd’s domain-binding API. Boxd then verifies and activates the domain certificate in its own control loop. Panel/Wings installation retains the existing installer’s canonical Boxd-created Panel hostname; a user domain is an additional binding.

## SSH access limitation

The bot will not fabricate a username or password. Boxd documents a one-year SSH password token created from its signed-in Mobile page, and the published SDK used here does not expose a supported method for the bot to create or share that token. The bot can display the Boxd hostname, public IP, and SSH port and provide the Boxd Mobile link; an account that has access to the machine must generate the token.

## Installer and verification

The existing Panel/Wings/Nightshift install script is included at `scripts/install-panel-wings.sh`. It targets a fresh Ubuntu 24.04 Boxd machine, uses the Boxd-created hostname for the primary Panel URL, installs the Panel and Wings, and reports progress through the bot. It refuses to overwrite an existing Panel. The installer and provisioning behavior are tested with mocks and local syntax checks only; no live Boxd machine was created and no Boxd billing was consumed for this project.

The installer’s Panel login password is generated for the Panel account and sent to the owner in a private Telegram message. It is not an SSH password.

## Official references

Implementation details verified against the official Boxd sources are collected in [`docs/REFERENCE.md`](docs/REFERENCE.md), including the SDK, supported resource sizes, regions, quota fields, custom-domain DNS flow, and Mobile SSH token behavior. Panel package requirements were checked against the official [Pterodactyl installation guide](https://pterodactyl.io/panel/1.0/getting_started.html).
