const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const { verifyInitData } = require('../lib/webapp');

const TOKEN = '123456:TEST_TOKEN_aaaaaaaaaaaaaaaaaaaaaaaaaaaa';
function sign(fields, token = TOKEN) {
  const params = new URLSearchParams(fields);
  const check = [...params.entries()].sort(([a], [b]) => (a < b ? -1 : 1)).map(([k, v]) => `${k}=${v}`).join('\n');
  const secret = crypto.createHmac('sha256', 'WebAppData').update(token).digest();
  params.set('hash', crypto.createHmac('sha256', secret).update(check).digest('hex'));
  return params.toString();
}
const NOW = Date.UTC(2026, 10, 17, 12, 0, 0);
const fresh = { auth_date: String(Math.floor(NOW / 1000) - 60), query_id: 'AAH', user: JSON.stringify({ id: 7324745438, username: 'tester' }) };

test('accepts correctly signed, fresh initData', () => {
  assert.equal(verifyInitData(sign(fresh), TOKEN, { now: NOW }).id, 7324745438);
});
test('rejects tampered data, wrong token, expired and missing data', () => {
  const good = sign(fresh);
  assert.equal(verifyInitData(good.replace('tester', 'hacker'), TOKEN, { now: NOW }), null);
  assert.equal(verifyInitData(good, 'other:token', { now: NOW }), null);
  assert.equal(verifyInitData(sign({ ...fresh, auth_date: String(Math.floor(NOW / 1000) - 999999) }), TOKEN, { now: NOW }), null);
  assert.equal(verifyInitData('', TOKEN, { now: NOW }), null);
  assert.equal(verifyInitData(undefined, TOKEN, { now: NOW }), null);
});
