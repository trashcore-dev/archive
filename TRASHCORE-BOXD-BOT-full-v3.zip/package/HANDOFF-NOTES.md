# Resume the TRASHCORE Panel + Wings install through Telegram

This bundle contains the bot source, installer, Compose/Dockerfile templates, tests, and setup notes. It intentionally excludes `.env`, the SQLite database, and `node_modules`.

## Run the bot

Use a host with Node.js 24 and npm. Copy `.env.example` to `.env`, then fill in `BOT_TOKEN`, `BOXD_API_KEY`, and `ADMIN_IDS` (comma-separated Telegram numeric user IDs). Keep `.env` private. From the project directory run:

```bash
npm ci
npm test
npm start
```

The bot's Telegram menu offers **Install Panel + Wings** and **Install Status**. Select the target VPS, start the install from the bot, and monitor its progress there.

## Target-machine status

Boxd machine `tc-73654-mwkeu9qc` (FRA) is running. Docker Engine is installed, but the daemon did not come up: `dockerd` exits before `docker info` can connect. The machine's PID 1 is `sh`, not systemd; it has a systemd Docker unit but no active service manager or SysV Docker init script. A direct daemon start also ended with a Moby shutdown panic. The stale socket created by the attempts was removed; no Docker daemon/socket is currently running.

The Pterodactyl installer was **not** rerun. Its preflight requires a working `docker info` and a successful `docker run --rm hello-world`, so do not restart the Panel + Wings installation on this target until Docker is healthy.
