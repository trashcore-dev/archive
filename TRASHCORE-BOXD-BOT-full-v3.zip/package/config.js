require('dotenv').config();
const path = require('node:path');

const adminIds = String(process.env.ADMIN_IDS || '')
  .split(',').map(value => value.trim()).filter(Boolean);
if (adminIds.some(id => !/^\d+$/.test(id))) {
  throw new Error('ADMIN_IDS must contain only comma-separated Telegram numeric user IDs.');
}

module.exports = {
  botToken: String(process.env.BOT_TOKEN || '').trim(),
  boxdApiKey: String(process.env.BOXD_API_KEY || '').trim(),
  adminIds,
  botName: process.env.BOT_NAME || 'TRASHCORE VPS BOT',
  dbPath: path.resolve(process.env.DB_PATH || path.join(__dirname, 'database.sqlite')),
  menuImage: path.join(__dirname, 'assets', 'trashcore-vps-welcome.png'),
  initialCredits: Number.isSafeInteger(Number(process.env.INITIAL_CREDITS))
    ? Math.max(0, Number(process.env.INITIAL_CREDITS)) : 0,
  vpsCost: 100,
  dailyReward: 10,
  timezone: 'Africa/Nairobi',
  // Telegram Mini App dashboard (needs a public HTTPS URL that reaches WEBAPP_PORT)
  webAppUrl: /^https:\/\//i.test(String(process.env.WEBAPP_URL || '').trim())
    ? String(process.env.WEBAPP_URL).trim().replace(/\/+$/, '') : '',
  webAppPort: Number(process.env.WEBAPP_PORT) || 3000,
  webAppHost: process.env.WEBAPP_HOST || '0.0.0.0',
  // Coloured inline buttons (Bot API 9.4+). Set BUTTON_COLORS=off to disable.
  buttonColors: !/^(0|false|off|no)$/i.test(String(process.env.BUTTON_COLORS || 'on'))
};
